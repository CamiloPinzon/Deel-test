To work properly with this project you shoul locate on this ubication and run the next console commands:

_to install_ : npm i
_to run_: npm run dev
